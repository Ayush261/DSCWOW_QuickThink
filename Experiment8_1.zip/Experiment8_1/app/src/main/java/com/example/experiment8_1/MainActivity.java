package com.example.experiment8_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
    Button b1, b2;
    EditText et1;
    private String file = "data";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b1.setOnClickListener(new View().OnClickListener() {
            @Override
            public void onClick(View view) {

                et1 = (EditText) findViewById(R.id.editText);
                String text = et1.getText().toString();
                try {

                    FileOutputStream fout = openFileOutput(file, MODE_PRIVATE);
                    fout.write(text.getBytes());
                    fout.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String ans = " ";
                int c;
                try {


                    FileInputStream fin = openFileInput(file);
                    while ((c = fin.read()) != -1) {
                        ans = ans + Character.toString((char) c);
                    }


                    fin.close();
                }

                catch (IOException e) {
                    e.printStackTrace();
                }
                TextView t1 = (TextView) findViewById(R.id.textView2);
                t1.setText(ans);
            }


        });
    }
}