package com.example.experiment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    //The way of defining a log as private static final String Tag = "MyActivity"
   private static final String TAG = ".MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //The message format of log - Log.d(tag, message);
        Log.i(TAG,"OnCreate");
    }
    //The log messages are not clickable further they provide extra information about activity.
    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"OnStart");

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"OnResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"OnPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG,"OnStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG,"OnDestroy");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG,"ReStart");
    }
    public void openActivity2(View v)
    {
        Intent intent = new Intent(this,Activity2.class) ;
        startActivity(intent);


    }
}
