package com.example.internwork;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class InternDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "SmartSkillTraining";
    private static final int DATBASE_VERSION = 1;
    //The tables we create.
    public static final String TABLE_Curriculum = "curriculum";
    public static final String TABLE_Course = "course";
    public static final String TABLE_Concept = "concept";
    public static final String TABLE_SubConcept = " subconcept";
    public static final String TABLE_Session = " session";
    public static final String TABLE_Student = " student";

    //The columns of a specific tables seprated by spaces.
    public static final String g_curriculum_id = "curriculum_id";
    public static String CU_Name = "curriculum_name";
    public static String CU_Desc = "curriculum_description";
    public static String CU_Image = "curriculum_id";
    //2
    public static final String g_course_id = "course_id";
    public static final String CO_Name = "curriculum_name";
    public static final String CO_Desc = "curriculum_description";
    public static final String CO_Duration = "curriculum_duration";
    public static final String CO_Image = "course_image";
    //3
    public static final String g_concept_id = "concept_id";
    public static final String C_Name = "curriculum_name";
    public static final String C_Desc = "curriculum_description";
    public static final String C_Duration = "curriculum_duration";
    public static final String C_Insert_Data = " insert_data";
    //4
    public static final String g_subconcept_id = "subconcept_id";
    public static final String SC_Name = "curriculum_name";
    public static final String SC_Desc = "curriculum_description";
    public static final String SC_Duration = "curriculum_duration";
    public static final String SC_Insert_Data = " insert_data";
    //5
    public static final String g_session_id = "session_id";
    public static final String SP_Name = "session_name";
    public static final String SP_Duration = "session_duration";
    public static final String SP_Sequence = " sequence";
    //6
    public static final String ST_id = "student_id";
    public static final String ST_Username = "session_name";
    public static final String ST_Salutation = "session_duration";
    public static final String ST_Firstname = "student_firstname";
    public static final String ST_Lastname = "student_lastname";
    public static final String ST_Password = "student_password";
    public static final String ST_Dob = "student_dateofbirth";
    public static final String ST_Address = "student_address";
    public static final String ST_Insertdate = "student_insertdate";

    // Creation of the tables Started.
    private static final String CREATE_TABLE_Curriculum = "create table " + TABLE_Curriculum + "(" + g_curriculum_id
            + " INTEGER PRIMARY KEY AUTOINCREMENT , " + CU_Name + " TEXT, " + CU_Desc + "TEXT" + CU_Image + " BLOB);";
    // Creation of the tables Started.
    private static final String CREATE_TABLE_Course = "create table " + TABLE_Course + "(" + g_course_id + " INTEGER PRIMARY KEY AUTOINCREMENT ," + CO_Name + " TEXT ," + CO_Desc + "TEXT ," + CO_Duration + " DEFAULT NULL ," + CO_Image + "TEXT);";
    // Creation of the tables Started.
    private static final String CREATE_TABLE_Concept = "create table " + TABLE_Concept + "(" + g_concept_id + " INTEGER PRIMARY KEY AUTOINCREMENT  ," + C_Name + " TEXT ," + C_Desc + "TEXT ," + C_Duration + " DEFAULT NULL ," + C_Insert_Data + " DEFAULT NULL);";
    // Creation of the tables Started.
    private static final String CREATE_TABLE_SubConcept = "create table " + TABLE_SubConcept + "(" + g_subconcept_id + " INTEGER PRIMARY KEY AUTOINCREMENT ," + C_Name + " TEXT ," + SC_Desc + "TEXT ," + SC_Duration + " DEFAULT NULL ," + SC_Insert_Data + " DEFAULT NULL);";
    // creation of the tables Started
    private static final String CREATE_TABLE_Session = "create table " + TABLE_Session + "(" + g_session_id + " INTEGER PRIMARY KEY AUTOINCREMENT ," + SP_Name + " TEXT ," + SP_Duration + " DEFAULT NULL ," + SP_Sequence + " DEFAULT NULL);";
    // creation of the tables Started
    private static final String CREATE_TABLE_Student = "create table " + TABLE_Student + "(" + ST_id + " INTEGER PRIMARY KEY AUTOINCREMENT ," + ST_Username + " TEXT ," + ST_Salutation + " TEXT ," + ST_Firstname + " TEXT ," + ST_Lastname + " TEXT ," + ST_Password + " TEXT ," + ST_Dob + " DEFAULT NULL ," + ST_Address + " TEXT ," + ST_Insertdate + " DEFAULT NULL);";

    private SQLiteDatabase db;

    InternDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATBASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE_Curriculum);
        db.execSQL(CREATE_TABLE_Course);
        db.execSQL(CREATE_TABLE_Concept);
        db.execSQL(CREATE_TABLE_SubConcept);
        db.execSQL(CREATE_TABLE_Session);
        db.execSQL(CREATE_TABLE_Student);
       //db.insert( TABLE_Curriculum ,null,1);
      // db.insert(TABLE_Concept , null, 1);
      // db.insert(TABLE_Course , null ,1);
      // db.insert( TABLE_SubConcept , null ,1);
      // db.insert(TABLE_Session , null ,1);

    }

    public Object TABLE_Curriculum(String g_curriculum_id, String cu_name, String cu_desc, String cu_image) {
        g_curriculum_id = " 1 ";
        CU_Name = " Computer Networks";
        CU_Desc = "All about Networking and connectivity";
        CU_Image = "Circum";
        return TABLE_Curriculum;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Curriculum);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Course);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Concept);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SubConcept);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Session);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Student);

        onCreate(db);
    }

}

