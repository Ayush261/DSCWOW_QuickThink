package com.example.internwork;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class client extends AppCompatActivity implements View.OnClickListener {
    public static final int SERVERPORT = 3003;

    public static final String SERVER_IP = "192.168.225.181";
    private ClientThread clientThread;
    private Thread thread;
    private LinearLayout msgList;
    private Handler handler;
    private int clientTextColor;
    private EditText edMessage;
    private InternDbHelper dbManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);
        //dbManager = new DBManager(this);
        //dbManager.open();
        setTitle("Client");
        clientTextColor = ContextCompat.getColor(this, R.color.green);
        handler = new Handler();
        msgList = findViewById(R.id.msgList);
        edMessage = findViewById(R.id.edMessage);
    }
    //kj

    public TextView textView(String message, int color) {
        if (null == message || message.trim().isEmpty()) {
            message = "<Empty Message>";
        }
        TextView tv = new TextView(this);
        tv.setTextColor(color);
        tv.setText(message + " [" + getTime() + "]");
        tv.setTextSize(20);
        tv.setPadding(0, 5, 0, 0);
        return tv;
    }

    public void showMessage(final String message, final int color) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                msgList.addView(textView(message, color));
            }
        });
    }

    public void onClick(View view) {

        if (view.getId() == R.id.connect_server) {
            msgList.removeAllViews();
            showMessage("Connecting to Server...", clientTextColor);
            clientThread = new ClientThread();
            thread = new Thread(clientThread);
            thread.start();
            showMessage("Connected to Server...", clientTextColor);
            //return;
           // Intent f1 = new Intent(client.this,Faqopen.class);
          //  startActivity(f1);
           // Toast.makeText(getApplicationContext(),"Welcome ToFrequently Asked Question To Session", Toast.LENGTH_SHORT).show();
        }

        if (view.getId() == R.id.send_data) {
            String clientMessage = edMessage.getText().toString().trim();
            showMessage(clientMessage, Color.BLUE);
            if (null != clientThread) {
                clientThread.sendMessage(clientMessage);
            }
        }
    }

    class ClientThread implements Runnable {

        private Socket socket;
        private BufferedReader input;
        private String  g_curriculum_id ;
        private String g_course_id;
        private String g_concept_id;
        private String g_subconcept_id;
        private  String g_session_id;
        private int values;
        private int value;
        private  int valu;
        private  int val;
        private  int va;

        @Override
        public void run() {

            try {
                InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
                socket = new Socket(serverAddr, SERVERPORT);

                while (!Thread.currentThread().isInterrupted()) {

                    this.input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String message = input.readLine();
                    if (null == message || "Disconnect".contentEquals(message)) {
                        Thread.interrupted();
                        message = "Server Disconnected.";
                        showMessage(message, Color.RED);
                        break;
                    }
                    //Addition to the new part using split.
                    String[] arrSplitmessage = message.split(" / ");
                  //  for (int i = 0; i < arrSplitmessage.length; i++) {
                        g_curriculum_id = arrSplitmessage[0];
                        g_course_id = arrSplitmessage[1];
                        g_session_id = arrSplitmessage[4];
                   // }
                    boolean a = g_curriculum_id.equals(dbManager.g_curriculum_id);
                    boolean b = g_course_id.equals(dbManager.g_course_id);
                    boolean c = g_concept_id.equals(dbManager.g_concept_id);
                    boolean d = g_subconcept_id.equals(dbManager.g_subconcept_id);
                    boolean e = g_session_id.equals(dbManager.g_session_id);

                   showMessage("Server: " +g_curriculum_id+ "" +  g_course_id + " " + g_concept_id + "" +g_subconcept_id +" " +g_session_id , clientTextColor);
                    if(a)
                    {
                       values = 1;
                    }
                    else
                    {
                         values = 0;
                    }
                    if(b)
                    {
                        value = 1;
                    }
                    else
                    {
                        value = 0;
                    }
                    if(c)
                    {
                        valu = 1;
                    }
                    else
                    {
                        valu = 0;
                    }
                    if(d)
                    {
                        val = 1;
                    }
                    else
                    {
                        val = 0;
                    }
                    if(e)
                    {
                        va = 1;
                    }
                    else
                    {
                        va = 0;
                    }
             if ( values == 1 && value == 1 && valu == 1 && val == 1 && va== 1 )
                    {
                        Intent f1 = new Intent(client.this,Faqopen.class);
                        startActivity(f1);
                        Toast.makeText(getApplicationContext(),"Welcome ToFrequently Asked Question To Session", Toast.LENGTH_SHORT).show();
                    }
                        // showMessage("Server: " + message, clientTextColor);
                }

            } catch (UnknownHostException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                showMessage("Problem Connecting to server..Check your server IP and Port and try again", Color.RED);
                e1.printStackTrace();
            }
        }

        void sendMessage(final String message) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (null != socket) {
                            PrintWriter out = new PrintWriter(new BufferedWriter(
                                    new OutputStreamWriter(socket.getOutputStream())),
                                    true);
                            out.println(message);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

    }

    String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != clientThread) {
            clientThread.sendMessage("Disconnect");
            clientThread = null;
        }
    }
}
    